/* for using dakota.so */

extern int main1(int, char**);

 int
main(int argc, char **argv)
{ return main1(argc, argv); }
