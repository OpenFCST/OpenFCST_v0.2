// -- AUTO GENERATED FILE; DO NOT EDIT --
        #include "DakotaBuildInfo.hpp"
        std::string Dakota::DakotaBuildInfo::releaseNum="5.4";
        std::string Dakota::DakotaBuildInfo::rev="2206";
        // ToDo: Gather SVN rev for key TPLs, e.g. pecos, surfpack, etc.
        //       Lower priority - a post-5.4 release task
        