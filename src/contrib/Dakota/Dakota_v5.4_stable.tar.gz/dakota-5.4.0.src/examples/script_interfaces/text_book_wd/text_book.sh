# Ensure the text_book executable is your $PATH
#   module load dakota
# or
#   export PATH=$DAKOTA_PREFIX/test:$PATH:.

text_book $1 $2

